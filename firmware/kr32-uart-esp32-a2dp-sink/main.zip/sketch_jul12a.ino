#define SCROLL_HOLD_TIME 2000     // Мс на початку і в кінці (нульова позиція)
#define SCROLL_STEP_TIME 300      // Мс між кроками
#define DISPLAY_WIDTH 8

#include <SPI.h>

// === UTF-8 → Unicode decoder ===
size_t utf8_to_unicode(const uint8_t *input, uint32_t *codepoint) {
  uint8_t b0 = input[0];

  if (b0 <= 0x7F) {
    *codepoint = b0;
    return 1;
  } else if ((b0 & 0xE0) == 0xC0) {
    *codepoint = ((b0 & 0x1F) << 6) | (input[1] & 0x3F);
    return 2;
  } else if ((b0 & 0xF0) == 0xE0) {
    *codepoint = ((b0 & 0x0F) << 12) | ((input[1] & 0x3F) << 6) | (input[2] & 0x3F);
    return 3;
  } else if ((b0 & 0xF8) == 0xF0) {
    *codepoint = ((b0 & 0x07) << 18) | ((input[1] & 0x3F) << 12) |
                 ((input[2] & 0x3F) << 6) | (input[3] & 0x3F);
    return 4;
  }

  return 0; // Invalid UTF-8
}

// === Unicode → VFD font code ===
uint8_t unicode_to_vfd(uint32_t cp) {
  if (cp >= 0x20 && cp <= 0x7E) return cp;

  // Часткова кирилиця
  switch (cp) {
    case 0x0: return ' ';
    case 0x0411: return 0xDA; // Б
    case 0x0413: return 0xDB; // Г
    case 0x0414: return 0xDC; // Д
    case 0x0404: return 0xB4; // Є
    case 0x0416: return 0xDD; // Ж
    case 0x0417: return 0xDE; // З
    case 0x0418: return 0xDF; // И
    case 0x0407: return 0xD4; // Ї
    case 0x0419: return 0xE0; // Й
    case 0x041B: return 0xE1; // Л
    case 0x041F: return 0xE2; // П
    case 0x0423: return 0xE3; // У
    case 0x0424: return 0xE4; // Ф
    case 0x0426: return 0xE5; // Ц
    case 0x0427: return 0xE6; // Ч
    case 0x0428: return 0xE7; // Ш
    case 0x0429: return 0xE8; // Щ
    case 0x042A: return 0xE9; // Ъ
    case 0x042B: return 0xEA; // Ы
    case 0x042C: return 0xE9; // Ь->Ъ
    case 0x042D: return 0xEB; // Э
    case 0x042E: return 0xEC; // Ю
    case 0x042F: return 0xED; // Я
    case 0x0490: return 0xDB; // Ґ->Г

    // Візуально схожі:
    case 0x0410: return 'A'; // А
    case 0x0412: return 'B'; // В
    case 0x0415: return 'E'; // Е
    case 0x0406: return 'I'; // І
    case 0x041A: return 'K'; // К
    case 0x041C: return 'M'; // М
    case 0x041D: return 'H'; // Н
    case 0x041E: return 'O'; // О
    case 0x0420: return 'P'; // Р
    case 0x0421: return 'C'; // С
    case 0x0422: return 'T'; // Т
    case 0x0425: return 'X'; // Х

    /// Малі (відображаються як великі) ///
    case 0x0431: return 0xDA; // б
    case 0x0433: return 0xDB; // г
    case 0x0434: return 0xDC; // д
    case 0x0454: return 0xB4; // є
    case 0x0436: return 0xDD; // ж
    case 0x0437: return 0xDE; // з
    case 0x0438: return 0xDF; // и
    case 0x0457: return 0xD4; // ї
    case 0x0439: return 0xE0; // й
    case 0x043B: return 0xE1; // л
    case 0x043F: return 0xE2; // п
    case 0x0443: return 0xE3; // у
    case 0x0444: return 0xE4; // ф
    case 0x0446: return 0xE5; // ц
    case 0x0447: return 0xE6; // ч
    case 0x0448: return 0xE7; // ш
    case 0x0449: return 0xE8; // щ
    case 0x044A: return 0xE9; // Ъ
    case 0x044B: return 0xEA; // Ы
    case 0x044C: return 0xE9; // ь->Ъ
    case 0x044D: return 0xEB; // Э
    case 0x044E: return 0xEC; // ю
    case 0x044F: return 0xED; // я
    case 0x0491: return 0xDB; // ґ->г

    // Візуально схожі:
    case 0x0430: return 'A'; // а
    case 0x0432: return 'B'; // в
    case 0x0435: return 'E'; // е
    case 0x0456: return 'I'; // і
    case 0x043A: return 'K'; // к
    case 0x043C: return 'M'; // м
    case 0x043D: return 'H'; // н
    case 0x043E: return 'O'; // о
    case 0x0440: return 'P'; // р
    case 0x0441: return 'C'; // с
    case 0x0442: return 'T'; // т
    case 0x0445: return 'X'; // х

    default: return ' ';
  }
}

class VFDisplay
{
  public:
    VFDisplay() {};
    void begin()
    {
      SPI.begin(SCK, MISO, MOSI, SS);
      pinMode(Reset, OUTPUT);
      pinMode(CS, OUTPUT);
      digitalWrite(Reset, LOW);
      delayMicroseconds(5);
      digitalWrite(Reset, HIGH);

      setDigitCount(8);
      setBrightness(255);
      Serial.printf("VFD_init\n");
    }
    void putChar(unsigned char x, char chr)
    {
      digitalWrite(CS, LOW);
      writeDisplay(0x20 + x);
      writeDisplay(chr);
      digitalWrite(CS, HIGH);
      show();
    }
    void printString(char *str)
    {
      int x = 0;
      while (*str)
      {
        putChar(x++, *str++);
      }
    }
    void printUTF8(const char *str, int startPos = 0) {
      int x = startPos;
      while (*str && x < 8) {
        if (str[0] == '\\' && str[1] == 'x' &&
            isxdigit(str[2]) && isxdigit(str[3])) {
          // Спеціальна escape-послідовність \xNN
          char hex[3] = {str[2], str[3], '\0'};
          uint8_t vfd_char = strtoul(hex, NULL, 16);
          putChar(x++, vfd_char);
          str += 4;
          continue;
        }

        uint32_t cp;
        size_t len = utf8_to_unicode((const uint8_t *)str, &cp);
        if (len == 0) {
          cp = '?';
          len = 1;
        }
        uint8_t vfd_char = unicode_to_vfd(cp);
        putChar(x++, vfd_char);
        str += len;
      }
    }
  private:
    void setDigitCount(uint8_t count)
    {
      digitalWrite(CS, LOW);
      writeDisplay(0xe0);
      delayMicroseconds(5);
      writeDisplay(count - 1);
      digitalWrite(CS, HIGH);
      delayMicroseconds(5);
    }
    void setBrightness(uint8_t brightness)
    {
      digitalWrite(CS, LOW);
      writeDisplay(0xe4);
      delayMicroseconds(5);
      writeDisplay(brightness);
      digitalWrite(CS, HIGH);
      delayMicroseconds(5);
    }
    void show()
    {
      digitalWrite(CS, LOW);
      writeDisplay(0xe8);
      digitalWrite(CS, HIGH);
    }
    void writeDisplay(uint8_t b)
    {
      SPI.beginTransaction(SPISettings(1000000, LSBFIRST, SPI_MODE0));
      SPI.write(b);
      SPI.endTransaction();
    }

    uint8_t Reset = 15;
    uint8_t CS = 12;
    uint8_t SCK = 4;
    uint8_t MOSI = 2;
    uint8_t MISO = 19;
    uint8_t SS = 12; // not actually used - see CS above

};

VFDisplay vfdisplay;

bool printScrollingUTF8(VFDisplay& display, const char* str, uint8_t scrollMode = 0) {
  static uint32_t lastScrollTime = 0;
  static int scrollPos = 0;
  static bool scrollHold = false;
  static bool finishedScroll = false;
  static bool needHold = false; // новий прапорець
  static std::vector<uint8_t> vfdChars;
  static String prevStr = "";
  static uint8_t prevScrollMode = 255;

  // Якщо рядок або режим змінився — скидаємо стан
  if (scrollMode != prevScrollMode || prevStr != String(str)) {
    scrollPos = 0;
    scrollHold = false;
    needHold = false;
    finishedScroll = false;
    lastScrollTime = millis();
    prevStr = str;
    prevScrollMode = scrollMode;

    vfdChars.clear();

    // Розбити UTF-8 → Unicode → VFD-коди
    const char* p = str;
    while (*p) {
      uint32_t cp;
      size_t len = utf8_to_unicode((const uint8_t*)p, &cp);
      if (len == 0) len = 1;
      uint8_t vfd = unicode_to_vfd(cp);
      vfdChars.push_back(vfd);
      p += len;
    }

    // Додаємо DISPLAY_WIDTH пробілів у кінець — для повного зсуву вліво
    /*for (int i = 0; i < DISPLAY_WIDTH; i++) {
      vfdChars.push_back(' ');
      }*/
  }

  // Пауза на кожному поверненні до початкового положення (позиція 0)
  if (scrollPos == 1 && !needHold) {
    scrollHold = true;
    needHold = true;
    lastScrollTime = millis();
  }

  // Виконуємо затримку прокрутки
  if (scrollHold) {
    if (millis() - lastScrollTime < SCROLL_HOLD_TIME) return false;
    scrollHold = false;
    lastScrollTime = millis();
  }


  // Прокручуємо текст
  if (millis() - lastScrollTime >= SCROLL_STEP_TIME) {
    lastScrollTime = millis();

    // Вивести DISPLAY_WIDTH символів
    for (int i = 0; i < DISPLAY_WIDTH; i++) {
      int idx = scrollPos + i;
      if (idx >= 0 && idx < (int)vfdChars.size()) {
        display.putChar(i, vfdChars[idx]);
      } else {
        display.putChar(i, ' ');
      }
    }

    scrollPos++;

    if (scrollPos > (int)vfdChars.size()) {
      scrollPos = -DISPLAY_WIDTH; // виїзд з правого краю
      scrollHold = false;
      needHold = false;

      if (scrollMode == 2) {
        finishedScroll = true;
      }
    }
  }

  return finishedScroll;
}


const char* textToScroll = "Музика: Привіт";
String input;

void setup() {
  Serial.begin(115200);
  vfdisplay.begin();
  //vfdisplay.printUTF8("Boot");
  while (!printScrollingUTF8(vfdisplay, "        Soundtech <<<<<<<<", 2)) {}
}

void loop() {
  if (Serial.available()) input = Serial.readString();
  char buffer[100]; // вибери достатній розмір буфера

  input.toCharArray(buffer, sizeof(buffer));
  printScrollingUTF8(vfdisplay, buffer, 1);
  //printScrollingUTF8(vfdisplay, "Бла бла бла", 1);
  delay(10); // неблокуюча пауза для запобігання перевантаження CPU
}
