#include "vfd_display.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/task.h"
#include "esp_timer.h"
//#include "esp_rom/ets_sys.h"
#include <cctype>
#include "vfd_display_utils.h"

static const char* TAG = "VFDisplay";

spi_device_handle_t spi;

VFDisplay::VFDisplay() {}

void VFDisplay::begin() {
    gpio_config_t io_conf = {};
    io_conf.intr_type = GPIO_INTR_DISABLE;
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pin_bit_mask = (1ULL << CS) | (1ULL << Reset);
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    gpio_config(&io_conf);

    gpio_set_level(Reset, 0);
    esp_rom_delay_us(5);
    gpio_set_level(Reset, 1);

    spi_bus_config_t buscfg = {};
	buscfg.miso_io_num = -1;
	buscfg.mosi_io_num = MOSI;
	buscfg.sclk_io_num = SCK;
	buscfg.quadwp_io_num = -1;
	buscfg.quadhd_io_num = -1;
	buscfg.max_transfer_sz = 2;

    spi_bus_initialize(HSPI_HOST, &buscfg, 1);

    spi_device_interface_config_t devcfg = {};
	devcfg.clock_speed_hz = 1000000;
	devcfg.mode = 0;
	devcfg.spics_io_num = CS;
	devcfg.queue_size = 1;
	devcfg.flags = SPI_DEVICE_HALFDUPLEX;

    spi_bus_add_device(HSPI_HOST, &devcfg, &spi);

    setDigitCount(8);
    setBrightness(255);
    ESP_LOGI(TAG, "VFD init done");
}

void VFDisplay::writeDisplay(uint8_t b) {
    spi_transaction_t t = {};
    t.length = 8;
    t.tx_buffer = &b;
    spi_device_transmit(spi, &t);
}

void VFDisplay::putChar(unsigned char x, char chr) {
    gpio_set_level(CS, 0);
    writeDisplay(0x20 + x);
    writeDisplay(chr);
    gpio_set_level(CS, 1);
    show();
}

void VFDisplay::printUTF8(const char* str, int startPos) {
    int x = startPos;
    while (*str && x < 8) {
        if (str[0] == '\\' && str[1] == 'x' && isxdigit(str[2]) && isxdigit(str[3])) {
            char hex[3] = {str[2], str[3], '\0'};
            uint8_t vfd_char = strtoul(hex, NULL, 16);
            putChar(x++, vfd_char);
            str += 4;
            continue;
        }
        uint32_t cp;
        size_t len = utf8_to_unicode((const uint8_t*)str, &cp);
        if (len == 0) { cp = '?'; len = 1; }
        uint8_t vfd_char = unicode_to_vfd(cp);
        putChar(x++, vfd_char);
        str += len;
    }
}

void VFDisplay::setDigitCount(uint8_t count) {
    gpio_set_level(CS, 0);
    writeDisplay(0xe0);
    esp_rom_delay_us(5);
    writeDisplay(count - 1);
    gpio_set_level(CS, 1);
    esp_rom_delay_us(5);
}

void VFDisplay::setBrightness(uint8_t brightness) {
    gpio_set_level(CS, 0);
    writeDisplay(0xe4);
    esp_rom_delay_us(5);
    writeDisplay(brightness);
    gpio_set_level(CS, 1);
    esp_rom_delay_us(5);
}

void VFDisplay::show() {
    gpio_set_level(CS, 0);
    writeDisplay(0xe8);
    gpio_set_level(CS, 1);
}