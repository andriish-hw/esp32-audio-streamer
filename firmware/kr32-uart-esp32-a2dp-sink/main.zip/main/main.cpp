#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

#include "BluetoothA2DPSinkQueued.h"
#include "vfd_display.h"
#include "vfd_scrolling.h"

I2SStream out;
BluetoothA2DPSinkQueued a2dp_sink(out);
VFDisplay vfdisplay;

bool is_playing = false;

// Поточний текст для прокрутки (тимчасово просто "BT Audio")
std::string current_metadata = "BT Audio";

void button_task(void*) {
    gpio_set_direction(GPIO_NUM_27, GPIO_MODE_INPUT);
    bool last_state = 1;

    // Ініціалізація стану
    esp_a2d_audio_state_t state = a2dp_sink.get_audio_state();
    is_playing = (state == ESP_A2D_AUDIO_STATE_STARTED);

    while (true) {
        bool pressed = (gpio_get_level(GPIO_NUM_27) == 0);

        if (pressed && !last_state) {
            if (is_playing) {
                a2dp_sink.pause();
            } else {
                a2dp_sink.play();
            }
            is_playing = !is_playing;
        }

        last_state = pressed;
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

// Завдання прокрутки тексту на дисплеї
void display_task(void*) {
    while (true) {
        //printScrollingUTF8(vfdisplay, current_metadata.c_str(), 0);
		vfdisplay.printUTF8("TEST", 0);
		//ESP_LOGI("LOG", "VFD print");
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

extern "C" void app_main(void)
{
    I2SConfig i2s_config;
    i2s_config.pin_ws = 26; // LRCK
    i2s_config.pin_bck = 22;  // BCLK
    i2s_config.pin_data = 25;  // DATA
    out.begin(i2s_config);

    vfdisplay.begin();

    a2dp_sink.set_auto_reconnect(true);
    a2dp_sink.set_task_core(0);
    a2dp_sink.start("ESP_SPEAKER");

    xTaskCreate(button_task, "button_task", 2048, NULL, 1, NULL);
    xTaskCreate(display_task, "display_task", 2048, NULL, 1, NULL);
}
