#include "vfd_scrolling.h"
#include "vfd_display_utils.h"
#include <vector>
#include <string>
#include <cstring>
#include "esp_timer.h"

#define SCROLL_HOLD_TIME 2000     // Мс на початку і в кінці (нульова позиція)
#define SCROLL_STEP_TIME 300      // Мс між кроками
#define DISPLAY_WIDTH 8

using std::vector;
using std::string;

bool printScrollingUTF8(VFDisplay& display, const char* str, uint8_t scrollMode) {
    static uint32_t lastScrollTime = 0;
    static int scrollPos = 0;
    static bool scrollHold = false;
    static bool finishedScroll = false;
    static bool needHold = false; // новий прапорець
    static vector<uint8_t> vfdChars;
    static std::string prevStr = "";
    static uint8_t prevScrollMode = 255;

    // Якщо рядок або режим змінився — скидаємо стан
    if (scrollMode != prevScrollMode || prevStr != std::string(str)) {
        scrollPos = 0;
        scrollHold = false;
        needHold = false;
        finishedScroll = false;
        lastScrollTime = esp_timer_get_time() / 1000;
        prevStr = str;
        prevScrollMode = scrollMode;

        vfdChars.clear();

        // Розбити UTF-8 → Unicode → VFD-коди
        const char* p = str;
        while (*p) {
            uint32_t cp;
            size_t len = utf8_to_unicode((const uint8_t*)p, &cp);
            if (len == 0) len = 1;
            uint8_t vfd = unicode_to_vfd(cp);
            vfdChars.push_back(vfd);
            p += len;
        }
    }

    // Пауза на кожному поверненні до початкового положення (позиція 0)
    if (scrollPos == 1 && !needHold) {
        scrollHold = true;
        needHold = true;
        lastScrollTime = esp_timer_get_time() / 1000;
    }

    // Виконуємо затримку прокрутки
    if (scrollHold) {
        if ((esp_timer_get_time() / 1000) - lastScrollTime < SCROLL_HOLD_TIME) return false;
        scrollHold = false;
        lastScrollTime = esp_timer_get_time() / 1000;
    }

    // Прокручуємо текст
    if ((esp_timer_get_time() / 1000) - lastScrollTime >= SCROLL_STEP_TIME) {
        lastScrollTime = esp_timer_get_time() / 1000;

        // Вивести DISPLAY_WIDTH символів
        for (int i = 0; i < DISPLAY_WIDTH; i++) {
            int idx = scrollPos + i;
            if (idx >= 0 && idx < (int)vfdChars.size()) {
                display.putChar(i, vfdChars[idx]);
            } else {
                display.putChar(i, ' ');
            }
        }

        scrollPos++;

        if (scrollPos > (int)vfdChars.size()) {
            scrollPos = -DISPLAY_WIDTH; // виїзд з правого краю
            scrollHold = false;
            needHold = false;

            if (scrollMode == 2) {
                finishedScroll = true;
            }
        }
    }

    return finishedScroll;
}
