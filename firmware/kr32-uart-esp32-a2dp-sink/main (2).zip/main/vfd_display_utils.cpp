#include "vfd_display.h"
#include <cctype>
#include <cstdlib>

size_t utf8_to_unicode(const uint8_t *input, uint32_t *codepoint) {
    uint8_t b0 = input[0];

    if (b0 <= 0x7F) {
        *codepoint = b0;
        return 1;
    } else if ((b0 & 0xE0) == 0xC0) {
        *codepoint = ((b0 & 0x1F) << 6) | (input[1] & 0x3F);
        return 2;
    } else if ((b0 & 0xF0) == 0xE0) {
        *codepoint = ((b0 & 0x0F) << 12) | ((input[1] & 0x3F) << 6) | (input[2] & 0x3F);
        return 3;
    } else if ((b0 & 0xF8) == 0xF0) {
        *codepoint = ((b0 & 0x07) << 18) | ((input[1] & 0x3F) << 12) |
                     ((input[2] & 0x3F) << 6) | (input[3] & 0x3F);
        return 4;
    }

    return 0; // Invalid UTF-8
}

uint8_t unicode_to_vfd(uint32_t cp) {
    if (cp >= 0x20 && cp <= 0x7E) return cp;

    switch (cp) {
        case 0x0: return ' ';
		case 0x00C0: return 0xD0;
		case 0x00C1: return 'A';
		case 0x00C2: return 0xD5;
		case 0x00C3: return 0xD5;
		case 0x00C4: return 0x8E;
		case 0x00C5: return 0x8F;
		case 0x00C6: return 0x92;
		case 0x00C7: return 0x80;
		case 0x00C8: return 0xD1;
		case 0x00C9: return 0x90;
		
		case 0x00E9: return 0x82;
        case 0x0411: return 0xDA;
        case 0x0413: return 0xDB;
        case 0x0414: return 0xDC;
        case 0x0404: return 0xB4;
        case 0x0416: return 0xDD;
        case 0x0417: return 0xDE;
        case 0x0418: return 0xDF;
        case 0x0407: return 0xD4;
        case 0x0419: return 0xE0;
        case 0x041B: return 0xE1;
        case 0x041F: return 0xE2;
        case 0x0423: return 0xE3;
        case 0x0424: return 0xE4;
        case 0x0426: return 0xE5;
        case 0x0427: return 0xE6;
        case 0x0428: return 0xE7;
        case 0x0429: return 0xE8;
        case 0x042A: return 0xE9;
        case 0x042B: return 0xEA;
        case 0x042C: return 0xE9;
        case 0x042D: return 0xEB;
        case 0x042E: return 0xEC;
        case 0x042F: return 0xED;
        case 0x0490: return 0xDB;
        case 0x0410: return 'A';
        case 0x0412: return 'B';
        case 0x0415: return 'E';
        case 0x0406: return 'I';
        case 0x041A: return 'K';
        case 0x041C: return 'M';
        case 0x041D: return 'H';
        case 0x041E: return 'O';
        case 0x0420: return 'P';
        case 0x0421: return 'C';
        case 0x0422: return 'T';
        case 0x0425: return 'X';
        case 0x0431: return 0xDA;
        case 0x0433: return 0xDB;
        case 0x0434: return 0xDC;
        case 0x0454: return 0xB4;
        case 0x0436: return 0xDD;
        case 0x0437: return 0xDE;
        case 0x0438: return 0xDF;
        case 0x0457: return 0xD4;
        case 0x0439: return 0xE0;
        case 0x043B: return 0xE1;
        case 0x043F: return 0xE2;
        case 0x0443: return 0xE3;
        case 0x0444: return 0xE4;
        case 0x0446: return 0xE5;
        case 0x0447: return 0xE6;
        case 0x0448: return 0xE7;
        case 0x0449: return 0xE8;
        case 0x044A: return 0xE9;
        case 0x044B: return 0xEA;
        case 0x044C: return 0xE9;
        case 0x044D: return 0xEB;
        case 0x044E: return 0xEC;
        case 0x044F: return 0xED;
        case 0x0491: return 0xDB;
        case 0x0430: return 'A';
        case 0x0432: return 'B';
        case 0x0435: return 'E';
        case 0x0456: return 'I';
        case 0x043A: return 'K';
        case 0x043C: return 'M';
        case 0x043D: return 'H';
        case 0x043E: return 'O';
        case 0x0440: return 'P';
        case 0x0441: return 'C';
        case 0x0442: return 'T';
        case 0x0445: return 'X';
        default: return ' ';
    }
}
