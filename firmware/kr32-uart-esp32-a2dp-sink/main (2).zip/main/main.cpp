#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

#include "BluetoothA2DPSinkQueued.h"
#include "vfd_display.h"
#include "vfd_scrolling.h"

I2SStream out;
BluetoothA2DPSinkQueued a2dp_sink(out);
VFDisplay vfdisplay;

bool is_playing = false;

// Поточний текст для прокрутки (тимчасово просто "BT Audio")
//const uint8_t* current_metadata = "BT Audio";

#define MAX_METADATA_LEN 64

char current_title[MAX_METADATA_LEN] = "";
char current_artist[MAX_METADATA_LEN] = "";
char display_buffer[MAX_METADATA_LEN * 2 + 4] = ""; // запас на " / " і '\0'

int utf8_strlen(const char* str) {
    int len = 0;
    while (*str) {
        uint8_t c = (uint8_t)*str;
        if ((c & 0b11000000) != 0b10000000) {
            // початок UTF-8 символу
            len++;
        }
        str++;
    }
    return len;
}

void printCleanUTF8(VFDisplay& display, const char* str, uint8_t pos) {
    char padded[9] = "        ";  // 8 пробілів + '\0'

    // копіюємо максимум 8 символів (UTF-8!)
    int i = 0;
    const char* p = str;
    while (*p && i < 8) {
        padded[p - str] = *p;
        uint8_t c = (uint8_t)*p;
        do {
            p++;
        } while ((*p & 0b11000000) == 0b10000000); // поки не початок символу
        i++;
    }
    display.printUTF8(padded, pos);
}

void avrc_metadata_callback(uint8_t id, const uint8_t* text) {
    if (!text) return;

    switch (id) {
        case ESP_AVRC_MD_ATTR_TITLE:
            strncpy(current_title, (const char*)text, MAX_METADATA_LEN - 1);
            current_title[MAX_METADATA_LEN - 1] = '\0';
            break;
        case ESP_AVRC_MD_ATTR_ARTIST:
            strncpy(current_artist, (const char*)text, MAX_METADATA_LEN - 1);
            current_artist[MAX_METADATA_LEN - 1] = '\0';
            break;
    }
}

void button_task(void*) {
    gpio_set_direction(GPIO_NUM_27, GPIO_MODE_INPUT);
    bool last_state = 1;

    // Ініціалізація стану
    esp_a2d_audio_state_t state = a2dp_sink.get_audio_state();
    is_playing = (state == ESP_A2D_AUDIO_STATE_STARTED);

    while (true) {
        bool pressed = (gpio_get_level(GPIO_NUM_27) == 0);

        if (pressed && !last_state) {
            if (is_playing) {
                a2dp_sink.pause();
            } else {
                a2dp_sink.play();
            }
            is_playing = !is_playing;
        }

        last_state = pressed;
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

// Завдання прокрутки тексту на дисплеї
void display_task(void*) {
    while (true) {
        // Формуємо вміст, уникаючи лишніх символів
        if (strlen(current_title) > 0 && strlen(current_artist) > 0) {
            snprintf(display_buffer, sizeof(display_buffer), "%s / %s", current_title, current_artist);
        } else if (strlen(current_title) > 0) {
            snprintf(display_buffer, sizeof(display_buffer), "%s", current_title);
        } else if (strlen(current_artist) > 0) {
            snprintf(display_buffer, sizeof(display_buffer), "%s", current_artist);
        } else {
            snprintf(display_buffer, sizeof(display_buffer), "BT Audio");
        }

        // Виведення з прокруткою або без
        if (strlen(display_buffer) > 8) {
            printScrollingUTF8(vfdisplay, display_buffer, 0);
        } else {
            printCleanUTF8(vfdisplay, display_buffer, 0);
        }

        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

extern "C" void app_main(void)
{
    I2SConfig i2s_config;
    i2s_config.pin_ws = 26; // LRCK
    i2s_config.pin_bck = 22;  // BCLK
    i2s_config.pin_data = 25;  // DATA
	//i2s_config.buffer_size = 8192;  // або навіть 8192, якщо затинання будуть знов
    out.begin(i2s_config);

    vfdisplay.begin();
	vTaskDelay(pdMS_TO_TICKS(100));

    a2dp_sink.set_auto_reconnect(true);
    a2dp_sink.set_task_core(1);
	a2dp_sink.set_task_priority(20);
	a2dp_sink.set_avrc_metadata_callback(avrc_metadata_callback);
    a2dp_sink.start("ESP_SPEAKER");

    xTaskCreatePinnedToCore(button_task, "button_task", 2048, NULL, 1, NULL, 0);
    xTaskCreatePinnedToCore(display_task, "display_task", 4096, NULL, 1, NULL, 0);
}
